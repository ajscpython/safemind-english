import EnglishClassPlatform from "../components/EnglishClassPlatform";
export default function Home() {
  return <EnglishClassPlatform />;
}
